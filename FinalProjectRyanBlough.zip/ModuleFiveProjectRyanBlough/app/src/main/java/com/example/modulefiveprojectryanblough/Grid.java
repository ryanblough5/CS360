package com.example.modulefiveprojectryanblough;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
public class Grid extends AppCompatActivity {

    int rowCount;
    Button del_1, del_2, del_3, del_4, del_5, add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.grid);
        del_1 = (Button) findViewById(R.id.del_1);
        del_2 = (Button) findViewById(R.id.del_2);
        del_3 = (Button) findViewById(R.id.del_3);
        del_4 = (Button) findViewById(R.id.del_4);
        del_5 = (Button) findViewById(R.id.del_5);
        add = (Button) findViewById(R.id.add);

        del_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int rowCount = 0;
                ViewGroup container = null;
                container.removeViews(rowCount, 0);
                container.invalidate();
            }
        });
        del_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int rowCount = 1;
                ViewGroup container = null;
                container.removeViews(rowCount, 1);
                container.invalidate();
            }
        });
        del_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int rowCount = 2;
                ViewGroup container = null;
                container.removeViews(rowCount, 2);
                container.invalidate();
            }
        });
        del_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int rowCount = 3;
                ViewGroup container = null;
                container.removeViews(rowCount, 3);
                container.invalidate();
            }
        });
        del_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int rowCount = 4;
                ViewGroup container = null;
                container.removeViews(rowCount, 4);
                container.invalidate();
            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
