package com.example.modulefiveprojectryanblough;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private int SMS_PERMISSION_CODE = 1;
    EditText username,password;
    Button signB, registerB, requestB;

    LoginDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        signB = (Button) findViewById(R.id.login_button);
        registerB = (Button) findViewById(R.id.register);
        db = new LoginDatabase(this);

        createNotificationChannel();

        signB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String User = username.getText().toString();
                String Pass = password.getText().toString();

                if (User.equals("") || Pass.equals("")) {
                    Toast.makeText(MainActivity.this, "Missing inforamtion", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkPass = db.checkUsernamePassword(User, Pass);
                    if (checkPass == true) {
                        Toast.makeText(MainActivity.this, "You are logged in", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), Grid.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "Username or Password incorrect", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        registerB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Register.class);
                startActivity(intent);
            }
        });
    }
private void createNotificationChannel(){
    CharSequence name = "Reminder";
    String desc = "Receive Reminder";
    int imp = NotificationManager.IMPORTANCE_DEFAULT;
    NotificationChannel ch = new NotificationChannel("receiveText", name, imp);
    ch.setDescription(desc);

    NotificationManager notificationManager = getSystemService((NotificationManager.class));
    notificationManager.createNotificationChannel(ch);
    }
}
